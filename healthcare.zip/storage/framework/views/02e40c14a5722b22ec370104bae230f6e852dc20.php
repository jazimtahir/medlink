<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">View Doctor</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.doctor.index')); ?>">Doctors</a>
                        </li>
                        <li class="breadcrumb-item"><a href="">View Doctor</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
<div class="content-body">
    <section>
        <div class="col-12">
            <div class="card">
                <div class="row">
                    <div class="col-4">
                        <div class="text-center">
                            <div class="card-body">
                                <img src="<?php echo e($doctor->getImg()); ?>" class="rounded-circle height-150" alt="Card image">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e($doctor->first_name . ' ' . $doctor->last_name); ?></h4>
                                <h6 class="card-subtitle text-muted"><span>@</span><?php echo e($doctor->username); ?></h6>
                                <h6 class="card-subtitle text-muted mt-1">
                                    <?php switch($doctor->gender):
                                        case ('M'): ?>
                                            Male
                                            <?php break; ?>
                                        <?php case ('F'): ?>
                                            Female
                                            <?php break; ?>
                                        <?php case ('T'): ?>
                                            Other
                                            <?php break; ?>
                                        <?php default: ?>
                                            No Gender provided
                                    <?php endswitch; ?>
                                </h6>
                                <?php if($doctor->is_verified): ?>
                                    <span class="badge badge-success mt-1">Verified</span>
                                <?php else: ?>
                                    <span class="badge badge-danger mt-1">Unverified</span>
                                <?php endif; ?>
                                <?php if($doctor->is_active): ?>
                                    <span class="badge badge-success mt-1">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-danger mt-1">Unactive</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-8">
                        <div class="card-body">
                            <table class="table table-column">
                                <tr>
                                    <td class="h4">Username:</td>
                                    <td><?php echo e($doctor->username); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Salutation:</td>
                                    <td><?php echo e($doctor->doctor->salutation); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">First Name:</td>
                                    <td><?php echo e($doctor->first_name); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Last Name:</td>
                                    <td><?php echo e($doctor->last_name); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Email:</td>
                                    <td><?php echo e($doctor->email); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Phone No:</td>
                                    <td><?php echo e($doctor->phone); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Date of Birth:</td>
                                    <td><?php echo e(date('d-M-Y', strtotime($doctor->dob))); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Address:</td>
                                    <td><?php echo e($doctor->address); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Bio:</td>
                                    <td><?php echo e($doctor->bio); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Fee:</td>
                                    <td><?php echo e($doctor->doctor->fee); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Practicing From:</td>
                                    <td><?php echo e(date('d-M-Y', strtotime($doctor->doctor->practicing_from))); ?></td>
                                </tr>
                                <tr>
                                    <td class="h4">Created at:</td>
                                    <td><?php echo e(date('d-m-Y', strtotime($doctor->created_at))); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/admin/doctor/show.blade.php ENDPATH**/ ?>