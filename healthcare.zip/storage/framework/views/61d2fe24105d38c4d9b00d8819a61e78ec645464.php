

<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <div class="row">
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="info"><?php echo e($activePatients); ?></h3>
                                    <h6>Active Patients</h6>
                                </div>
                                <div>
                                    <i class="ft ft-user-check info font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="warning"><?php echo e($activeDoctors); ?></h3>
                                    <h6>Active Doctors</h6>
                                </div>
                                <div>
                                    <i class="la la-stethoscope font-large-2 warning float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-warning" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="success"><?php echo e($totalPatients); ?></h3>
                                    <h6>Total Patients</h6>
                                </div>
                                <div>
                                    <i class="icon-user-follow success font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="danger"><?php echo e($totalDoctors); ?></h3>
                                    <h6>Total Doctors</h6>
                                </div>
                                <div>
                                    <i class="icon-heart danger font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Active Doctors</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered dom-jQuery-events">
                                    <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Salutation</th>
                                        <th>Username</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Specialization</th>
                                        <th style="width: 10%">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img class="avatar avatar-lg" src="<?php echo e($doctor->getImg()); ?>">
                                            </td>
                                            <td><?php echo e($doctor->doctor->salutation); ?></td>
                                            <td><?php echo e($doctor->username); ?></td>
                                            <td><?php echo e($doctor->first_name); ?></td>
                                            <td><?php echo e($doctor->last_name); ?></td>
                                            <td><?php echo e($doctor->email); ?></td>
                                            <td><?php echo e($doctor->phone); ?></td>
                                            <td><?php echo e($doctor->doctor->specialization->name ?? ''); ?></td>
                                            <td class="btn-toolbar">
                                                <div class="btn-group p-0">
                                                    <a class="btn btn-sm btn-outline-primary mr-1" href="<?php echo e(route('admin.doctor.show', [$doctor->id])); ?>">
                                                        <i class="la la-eye"></i>
                                                    </a>
                                                    <a class="btn btn-sm btn-outline-warning mr-1" href=""
                                                       data-toggle="modal"
                                                       data-target='#doctorEdit<?php echo e($doctor->id); ?>'
                                                    >
                                                        <i class="la la-edit"></i>
                                                    </a>
                                                    <a class="btn btn-sm btn-outline-danger" href="<?php echo e(route('admin.doctor.destroy', [$doctor->id])); ?>" onclick="return confirm('Are you sure?')">
                                                        <i class="la la-trash"></i>
                                                    </a>
                                                </div>
                                                
                                                <div class="modal fade text-left" id="doctorEdit<?php echo e($doctor->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h3 class="modal-title">Edit Doctor</h3>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <form method="POST" action="<?php echo e(route('admin.doctor.update', $doctor->id)); ?>" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="modal-body">
                                                                    <label>Username: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="text" name="username" value="<?php echo e($doctor->username); ?>" class="form-control" disabled>
                                                                        <div class="form-control-position">
                                                                            <i class="ft ft-user-check"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Email: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="email" name="email" value="<?php echo e($doctor->email); ?>" class="form-control" disabled>
                                                                        <div class="form-control-position">
                                                                            <i class="la la-envelope"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Phone: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="text" name="phone" value="<?php echo e($doctor->phone); ?>" class="form-control" disabled>
                                                                        <div class="form-control-position">
                                                                            <i class="la la-phone"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Salutation: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="text" name="salutation" value="<?php echo e($doctor->doctor->salutation); ?>" class="form-control">
                                                                        <div class="form-control-position">
                                                                            <i class="ft ft-info"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>First Name: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="text" name="first_name" value="<?php echo e($doctor->first_name); ?>" class="form-control">
                                                                        <div class="form-control-position">
                                                                            <i class="la la-user"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Last Name: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="text" name="last_name" value="<?php echo e($doctor->last_name); ?>" class="form-control">
                                                                        <div class="form-control-position">
                                                                            <i class="la la-user-plus"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Specialization: </label>
                                                                    <div class="form-group position-relative">
                                                                        <select class=" custom-select form-control" name="specialization_id">
                                                                            <option></option>
                                                                            <?php $__currentLoopData = $specialization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option <?php if($doctor->doctor->specialization && $doctor->doctor->specialization->name == $s->name): ?> selected <?php endif; ?> class="" value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>

                                                                    <label>Password: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="password" name="password" placeholder="Password" class="form-control">
                                                                        <div class="form-control-position">
                                                                            <i class="la la-lock"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Bio: </label>
                                                                    <div class="form-group position-relative">
                                                                        <textarea class="form-control" rows="5" name="bio" placeholder="Enter text ..."><?php echo e($doctor->bio); ?></textarea>
                                                                    </div>

                                                                    <label>Fee: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="number" name="fee" placeholder="Fee" class="form-control" value="<?php echo e($doctor->doctor->fee); ?>">
                                                                        <div class="form-control-position">
                                                                            <i class="la la-money"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Practicing From: </label>
                                                                    <div class="form-group position-relative has-icon-left">
                                                                        <input type="text" name="practicing_from" class="date-picker form-control" value="<?php echo e($doctor->doctor->practicing_from); ?>">
                                                                        <div class="form-control-position">
                                                                            <i class="ft ft-activity"></i>
                                                                        </div>
                                                                    </div>

                                                                    <label>Professional Statement: </label>
                                                                    <div class="form-group position-relative">
                                                                        <textarea class="form-control" rows="5" name="professional_statement" placeholder="Enter text ..."><?php echo e($doctor->doctor->professional_statement); ?></textarea>
                                                                    </div>

                                                                    <label>Address: </label>
                                                                    <div class="form-group position-relative">
                                                                        <textarea class="form-control" rows="3" name="address" placeholder="Enter address ..."><?php echo e($doctor->address); ?></textarea>
                                                                    </div>

                                                                    <label>Date of Birth: </label>
                                                                    <div class="form-group position-relative">
                                                                        <input type="text" class="date-picker form-control" name="dob" value="<?php echo e($doctor->dob); ?>">
                                                                    </div>

                                                                    <label>Profile Picture: </label>
                                                                    <div class="form-group position-relative">
                                                                        <input type="file" class="form-control" name="image">
                                                                    </div>

                                                                    <label>Activation Status: </label>
                                                                    <div class="form-group position-relative">
                                                                        <div class="input-group">
                                                                            <div class="d-inline-block custom-control custom-radio mr-1">
                                                                                <input type="radio" name="is_active" value="1" <?php echo e(($doctor->is_active=="1")? "checked" : ""); ?> class="custom-control-input" id="active1<?php echo e($doctor->id); ?>">
                                                                                <label class="custom-control-label" for="active1<?php echo e($doctor->id); ?>">Active</label>
                                                                            </div>
                                                                            <div class="d-inline-block custom-control custom-radio mr-1">
                                                                                <input type="radio" name="is_active" value="0" <?php echo e(($doctor->is_active=="0")? "checked" : ""); ?> class="custom-control-input" id="active0<?php echo e($doctor->id); ?>">
                                                                                <label class="custom-control-label" for="active0<?php echo e($doctor->id); ?>">InActive</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <label>Verification Status: </label>
                                                                    <div class="form-group position-relative">
                                                                        <div class="input-group">
                                                                            <div class="d-inline-block custom-control custom-radio mr-1">
                                                                                <input type="radio" name="is_verified" value="1" <?php echo e(($doctor->is_verified=="1")? "checked" : ""); ?> class="custom-control-input" id="verify1<?php echo e($doctor->id); ?>">
                                                                                <label class="custom-control-label" for="verify1<?php echo e($doctor->id); ?>">Verified</label>
                                                                            </div>
                                                                            <div class="d-inline-block custom-control custom-radio mr-1">
                                                                                <input type="radio" name="is_verified" value="0" <?php echo e(($doctor->is_verified=="0")? "checked" : ""); ?> class="custom-control-input" id="verify0<?php echo e($doctor->id); ?>">
                                                                                <label class="custom-control-label" for="verify0<?php echo e($doctor->id); ?>">Unverified</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                                                    <input type="submit" class="btn btn-outline-primary" value="Save">
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
        <div class="row">
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="info"><?php echo e(auth()->user()->doctor->getTodayAppointments()->count()); ?></h3>
                                    <h6>Today Appointments</h6>
                                </div>
                                <div>
                                    <i class="icon-basket-loaded info font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="warning"><?php echo e(auth()->user()->doctor->activeAppointments()->count()); ?></h3>
                                    <h6>Active Appointments</h6>
                                </div>
                                <div>
                                    <i class="la la-stethoscope font-large-2 warning float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-warning" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="success"><?php echo e(auth()->user()->doctor->canceledAppointments()->count()); ?></h3>
                                    <h6>Canceled Appointments</h6>
                                </div>
                                <div>
                                    <i class="icon-user-follow success font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="danger"><?php echo e(auth()->user()->doctor->appointments()->count()); ?></h3>
                                    <h6>Total Appointments</h6>
                                </div>
                                <div>
                                    <i class="icon-heart danger font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Today Appointments</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    </div>

                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Patient Username</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Status</th>
                                        <th style="width: 10%">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = auth()->user()->doctor->getTodayAppointments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($appointment->id); ?></td>
                                            <td><?php echo e($appointment->patient->user->username); ?></td>
                                            <td><?php echo e($appointment->start12()); ?></td>
                                            <td><?php echo e($appointment->end12()); ?></td>
                                            <td>
                                                <?php if($appointment->status == 'BOOKED'): ?>
                                                    <div class="badge badge-danger">PENDING</div>
                                                <?php elseif($appointment->status === 'DONE'): ?>
                                                    <div class="badge badge-success">DONE</div>
                                                <?php elseif($appointment->status === 'CANCELED'): ?>
                                                    <div class="badge badge-info">CANCELED</div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="btn-toolbar">
                                                <div class="btn-group p-0">
                                                    <a class="btn btn-sm btn-outline-primary mr-1" href="#"
                                                       data-toggle="modal"
                                                       data-target='#appointment<?php echo e($appointment->id); ?>'>
                                                        <i class="la la-eye"></i>
                                                    </a>
                                                </div>
                                                
                                                <div class="modal fade" id="appointment<?php echo e($appointment->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h3 class="modal-title">View Appointment</h3>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Patient Username:</b> <?php echo e($appointment->patient->user->username); ?>

                                                                    </div>
                                                                    <div class="col">
                                                                        <b>Day:</b> <?php echo e($appointment->dayName()); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Start Time:</b> <?php echo e($appointment->start12()); ?>

                                                                    </div>
                                                                    <div class="col">
                                                                        <b>End Time:</b> <?php echo e($appointment->end12()); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Reason for Appointment:</b> <?php echo e($appointment->reason); ?>

                                                                    </div>
                                                                </div>
                                                                <?php if($appointment->doctor_comment): ?>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Doctor Remarks:</b> <?php echo e($appointment->doctor_comment); ?>

                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <?php if($appointment->paid): ?>
                                                                            <div class="badge badge-success">PAID</div>
                                                                        <?php else: ?>
                                                                            <div class="badge badge-danger">UNPAID</div>
                                                                        <?php endif; ?>
                                                                        <?php if($appointment->status == 'BOOKED'): ?>
                                                                            <div class="badge badge-danger">PENDING</div>
                                                                        <?php elseif($appointment->status == 'DONE'): ?>
                                                                            <div class="badge badge-success"><?php echo e($appointment->status); ?></div>
                                                                        <?php elseif($appointment->status == 'CANCELED'): ?>
                                                                            <div class="badge badge-info"><?php echo e($appointment->status); ?></div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <?php if($appointment->canceled_by): ?>
                                                                    <div class="row">
                                                                        <div class="col">
                                                                            <?php if($appointment->canceled_by == 'doctor'): ?>
                                                                                <div class="badge badge-danger">Canceled by Doctor</div>
                                                                            <?php elseif($appointment->canceled_by == 'patient'): ?>
                                                                                <div class="badge badge-danger">Canceled by Patient</div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Newly Created Appointments</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    </div>

                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Patient Username</th>
                                        <th>Day</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Status</th>
                                        <th style="width: 10%">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = auth()->user()->doctor->todayCreatedAppointments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($appointment->id); ?></td>
                                            <td><?php echo e($appointment->patient->user->username); ?></td>
                                            <td><?php echo e($appointment->dayName()); ?></td>
                                            <td><?php echo e($appointment->start12()); ?></td>
                                            <td><?php echo e($appointment->end12()); ?></td>
                                            <td>
                                                <?php if($appointment->status == 'BOOKED'): ?>
                                                    <div class="badge badge-danger">PENDING</div>
                                                <?php elseif($appointment->status === 'DONE'): ?>
                                                    <div class="badge badge-success">DONE</div>
                                                <?php elseif($appointment->status === 'CANCELED'): ?>
                                                    <div class="badge badge-info">CANCELED</div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="btn-toolbar">
                                                <div class="btn-group p-0">
                                                    <a class="btn btn-sm btn-outline-primary mr-1" href="#"
                                                       data-toggle="modal"
                                                       data-target='#appointment<?php echo e($appointment->id); ?>'>
                                                        <i class="la la-eye"></i>
                                                    </a>
                                                </div>
                                                
                                                <div class="modal fade" id="appointment<?php echo e($appointment->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h3 class="modal-title">View Appointment</h3>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Patient Username:</b> <?php echo e($appointment->patient->user->username); ?>

                                                                    </div>
                                                                    <div class="col">
                                                                        <b>Day:</b> <?php echo e($appointment->dayName()); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Start Time:</b> <?php echo e($appointment->start12()); ?>

                                                                    </div>
                                                                    <div class="col">
                                                                        <b>End Time:</b> <?php echo e($appointment->end12()); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Reason for Appointment:</b> <?php echo e($appointment->reason); ?>

                                                                    </div>
                                                                </div>
                                                                <?php if($appointment->doctor_comment): ?>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Doctor Remarks:</b> <?php echo e($appointment->doctor_comment); ?>

                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <?php if($appointment->paid): ?>
                                                                            <div class="badge badge-success">PAID</div>
                                                                        <?php else: ?>
                                                                            <div class="badge badge-danger">UNPAID</div>
                                                                        <?php endif; ?>
                                                                        <?php if($appointment->status == 'BOOKED'): ?>
                                                                            <div class="badge badge-danger">PENDING</div>
                                                                        <?php elseif($appointment->status == 'DONE'): ?>
                                                                            <div class="badge badge-success"><?php echo e($appointment->status); ?></div>
                                                                        <?php elseif($appointment->status == 'CANCELED'): ?>
                                                                            <div class="badge badge-info"><?php echo e($appointment->status); ?></div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <?php if($appointment->canceled_by): ?>
                                                                    <div class="row">
                                                                        <div class="col">
                                                                            <?php if($appointment->canceled_by == 'doctor'): ?>
                                                                                <div class="badge badge-danger">Canceled by Doctor</div>
                                                                            <?php elseif($appointment->canceled_by == 'patient'): ?>
                                                                                <div class="badge badge-danger">Canceled by Patient</div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('patient')): ?>
        <div class="row">
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="info"><?php echo e(auth()->user()->patient->getTodayAppointments()->count()); ?></h3>
                                    <h6>Today Appointments</h6>
                                </div>
                                <div>
                                    <i class="icon-basket-loaded info font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="warning"><?php echo e(auth()->user()->patient->activeAppointments()->count()); ?></h3>
                                    <h6>Active Appointments</h6>
                                </div>
                                <div>
                                    <i class="la la-stethoscope font-large-2 warning float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-warning" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="success"><?php echo e(auth()->user()->patient->canceledAppointments()->count()); ?></h3>
                                    <h6>Canceled Appointments</h6>
                                </div>
                                <div>
                                    <i class="icon-user-follow success font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-12">
                <div class="card pull-up">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="media-body text-left">
                                    <h3 class="danger"><?php echo e(auth()->user()->patient->appointments()->count()); ?></h3>
                                    <h6>Total Appointments</h6>
                                </div>
                                <div>
                                    <i class="icon-heart danger font-large-2 float-right"></i>
                                </div>
                            </div>
                            <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Today Appointments</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    </div>
                    <?php if(auth()->user()->patient->getTodayAppointments()->count()): ?>
                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Doctor Username</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Status</th>
                                        <th style="width: 10%">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = auth()->user()->patient->getTodayAppointments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($appointment->id); ?></td>
                                            <td><?php echo e($appointment->doctor->user->username); ?></td>
                                            <td><?php echo e($appointment->start12()); ?></td>
                                            <td><?php echo e($appointment->end12()); ?></td>
                                            <td>
                                                <?php if($appointment->status == 'BOOKED'): ?>
                                                    <div class="badge badge-danger">PENDING</div>
                                                <?php elseif($appointment->status === 'DONE'): ?>
                                                    <div class="badge badge-success">DONE</div>
                                                <?php elseif($appointment->status === 'CANCELED'): ?>
                                                    <div class="badge badge-info">CANCELED</div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="btn-toolbar">
                                                <div class="btn-group p-0">
                                                    <a class="btn btn-sm btn-outline-primary mr-1" href="#"
                                                       data-toggle="modal"
                                                       data-target='#appointment<?php echo e($appointment->id); ?>'>
                                                        <i class="la la-eye"></i>
                                                    </a>
                                                </div>
                                                
                                                <div class="modal fade" id="appointment<?php echo e($appointment->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h3 class="modal-title">View Appointment</h3>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Doctor Username:</b> <?php echo e($appointment->doctor->user->username); ?>

                                                                    </div>
                                                                    <div class="col">
                                                                        <b>Day:</b> <?php echo e($appointment->dayName()); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Start Time:</b> <?php echo e($appointment->start12()); ?>

                                                                    </div>
                                                                    <div class="col">
                                                                        <b>End Time:</b> <?php echo e($appointment->end12()); ?>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <b>Reason for Appointment:</b> <?php echo e($appointment->reason); ?>

                                                                    </div>
                                                                </div>
                                                                <?php if($appointment->doctor_comment): ?>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Doctor Remarks:</b> <?php echo e($appointment->doctor_comment); ?>

                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <div class="row mb-1">
                                                                    <div class="col">
                                                                        <?php if($appointment->paid): ?>
                                                                            <div class="badge badge-success">PAID</div>
                                                                        <?php else: ?>
                                                                            <div class="badge badge-danger">UNPAID</div>
                                                                        <?php endif; ?>
                                                                        <?php if($appointment->status == 'BOOKED'): ?>
                                                                            <div class="badge badge-danger">PENDING</div>
                                                                        <?php elseif($appointment->status == 'DONE'): ?>
                                                                            <div class="badge badge-success"><?php echo e($appointment->status); ?></div>
                                                                        <?php elseif($appointment->status == 'CANCELED'): ?>
                                                                            <div class="badge badge-info"><?php echo e($appointment->status); ?></div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <?php if($appointment->canceled_by): ?>
                                                                    <div class="row">
                                                                        <div class="col">
                                                                            <?php if($appointment->canceled_by == 'doctor'): ?>
                                                                                <div class="badge badge-danger">Canceled by Doctor</div>
                                                                            <?php elseif($appointment->canceled_by == 'patient'): ?>
                                                                                <div class="badge badge-danger">Canceled by Patient</div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                        <div class="card-body">
                            No appointments today!
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Newly Created Appointments</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    </div>

                    <?php if(auth()->user()->patient->todayCreatedAppointments()->count()): ?>
                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Doctor Username</th>
                                            <th>Day</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Status</th>
                                            <th style="width: 10%">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = auth()->user()->patient->todayCreatedAppointments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($appointment->id); ?></td>
                                                <td><?php echo e($appointment->doctor->user->username); ?></td>
                                                <td><?php echo e($appointment->dayName()); ?></td>
                                                <td><?php echo e($appointment->start12()); ?></td>
                                                <td><?php echo e($appointment->end12()); ?></td>
                                                <td>
                                                    <?php if($appointment->status == 'BOOKED'): ?>
                                                        <div class="badge badge-danger">PENDING</div>
                                                    <?php elseif($appointment->status === 'DONE'): ?>
                                                        <div class="badge badge-success">DONE</div>
                                                    <?php elseif($appointment->status === 'CANCELED'): ?>
                                                        <div class="badge badge-info">CANCELED</div>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="btn-toolbar">
                                                    <div class="btn-group p-0">
                                                        <a class="btn btn-sm btn-outline-primary mr-1" href="#"
                                                           data-toggle="modal"
                                                           data-target='#appointment<?php echo e($appointment->id); ?>'>
                                                            <i class="la la-eye"></i>
                                                        </a>
                                                    </div>
                                                    
                                                    <div class="modal fade" id="appointment<?php echo e($appointment->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h3 class="modal-title">View Appointment</h3>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Doctor Username:</b> <?php echo e($appointment->doctor->user->username); ?>

                                                                        </div>
                                                                        <div class="col">
                                                                            <b>Day:</b> <?php echo e($appointment->dayName()); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Start Time:</b> <?php echo e($appointment->start12()); ?>

                                                                        </div>
                                                                        <div class="col">
                                                                            <b>End Time:</b> <?php echo e($appointment->end12()); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Reason for Appointment:</b> <?php echo e($appointment->reason); ?>

                                                                        </div>
                                                                    </div>
                                                                    <?php if($appointment->doctor_comment): ?>
                                                                        <div class="row mb-1">
                                                                            <div class="col">
                                                                                <b>Doctor Remarks:</b> <?php echo e($appointment->doctor_comment); ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <?php if($appointment->paid): ?>
                                                                                <div class="badge badge-success">PAID</div>
                                                                            <?php else: ?>
                                                                                <div class="badge badge-danger">UNPAID</div>
                                                                            <?php endif; ?>
                                                                            <?php if($appointment->status == 'BOOKED'): ?>
                                                                                <div class="badge badge-danger">PENDING</div>
                                                                            <?php elseif($appointment->status == 'DONE'): ?>
                                                                                <div class="badge badge-success"><?php echo e($appointment->status); ?></div>
                                                                            <?php elseif($appointment->status == 'CANCELED'): ?>
                                                                                <div class="badge badge-info"><?php echo e($appointment->status); ?></div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                    <?php if($appointment->canceled_by): ?>
                                                                        <div class="row">
                                                                            <div class="col">
                                                                                <?php if($appointment->canceled_by == 'doctor'): ?>
                                                                                    <div class="badge badge-danger">Canceled by Doctor</div>
                                                                                <?php elseif($appointment->canceled_by == 'patient'): ?>
                                                                                    <div class="badge badge-danger">Canceled by Patient</div>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card-body">
                            No Newly created appointments!
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/dashboard.blade.php ENDPATH**/ ?>