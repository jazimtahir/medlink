<div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-dark navbar-without-dd-arrow navbar-shadow" role="navigation" data-menu="menu-wrapper">
    <div class="navbar-container main-menu-content" data-menu="menu-container">
        <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="dropdown nav-item <?php if(request()->routeIs('dashboard') || request()->routeIs('admin.dashboard') || request()->routeIs('doctor.dashboard') || request()->routeIs('patient.dashboard')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="la la-home"></i>
                    <span data-i18n="Dashboard">Dashboard</span>
                </a>
            </li>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <li class="dropdown nav-item <?php if(request()->routeIs('admin.doctor.*')): ?> active <?php endif; ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
                    <i class="la la-stethoscope"></i><span>Doctors</span>
                </a>
                <ul class="dropdown-menu">
                    <li class="dropdown <?php if(request()->routeIs('admin.doctor.index')): ?> active <?php endif; ?>">
                        <a class="dropdown-item" href="<?php echo e(route('admin.doctor.index')); ?>" data-toggle="dropdown">
                            <i class="la la-check-square"></i><span >View Doctors</span></a>
                    </li>
                    <li class="dropdown <?php if(request()->routeIs('admin.doctor.create')): ?> active <?php endif; ?>">
                        <a class="dropdown-item" href="<?php echo e(route('admin.doctor.create')); ?>" data-toggle="dropdown">
                            <i class="la la-plus"></i><span>Add Doctor</span></a>
                    </li>
                </ul>
            </li>
            <li class="dropdown nav-item <?php if(request()->routeIs('admin.patient.*')): ?> active <?php endif; ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
                    <i class="la la-users"></i><span>Patients</span>
                </a>
                <ul class="dropdown-menu">
                    <li class="dropdown <?php if(request()->routeIs('admin.patient.index')): ?> active <?php endif; ?>">
                        <a class="dropdown-item" href="<?php echo e(route('admin.patient.index')); ?>">
                            <i class="la la-check-square"></i><span>View Patients</span></a>
                    </li>
                    <li class="dropdown <?php if(request()->routeIs('admin.patient.create')): ?> active <?php endif; ?>">
                        <a class="dropdown-item" href="<?php echo e(route('admin.patient.create')); ?>">
                            <i class="la la-plus"></i><span>Add Patient</span></a>
                    </li>
                </ul>
            </li>
            <li class="nav-item <?php if(request()->routeIs('admin.specialization.*')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.specialization.index')); ?>">
                    <i class="ft ft-clipboard"></i><span>Specializations</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
            <li class="nav-item <?php if(request()->routeIs('doctor.schedule')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('doctor.schedule')); ?>">
                    <i class="la la-hourglass"></i><span>My Schedule</span>
                </a>
            </li>
            <li class="nav-item <?php if(request()->routeIs('doctor.appointment')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('doctor.appointment')); ?>">
                    <i class="la la-group"></i><span>My Appointments</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('patient')): ?>
            <li class="nav-item <?php if(request()->routeIs('patient.appointment.doctors') || request()->routeIs('patient.appointment.schedule')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('patient.appointment.doctors')); ?>">
                    <i class="la la-plus"></i><span>Schedule New Appointment</span>
                </a>
            </li>
            <li class="nav-item <?php if(request()->routeIs('patient.appointment.index')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('patient.appointment')); ?>">
                    <i class="la la-group"></i><span>My Appointments</span>
                </a>
            </li>
            <?php endif; ?>
            <li class="dropdown nav-item <?php if(request()->routeIs('reviews')): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('reviews')); ?>">
                    <i class="la la-comments"></i>
                    <span data-i18n="Dashboard">Reviews</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\healthcare\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>