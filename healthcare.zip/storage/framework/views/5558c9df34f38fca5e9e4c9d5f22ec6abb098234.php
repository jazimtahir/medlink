<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Appointments</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">Schedule New Appointment</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <section>
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Available Time slots</div>
                    <div class="card-title text-muted">Please select a Timeslot to schedule an appointment:</div>
                    <br>
                    <div>
                        You are scheduling an appointment with <b><?php echo e($doctor->salutation . ' ' . $doctor->user->first_name . ' ' . $doctor->user->last_name); ?></b>
                    </div>
                    <br>
                    <label for="reason">Please specify reason for appointment: </label>
                    <input id="reason" class="form-control" type="text" name="reason" required>
                    <hr>
                    <?php $__currentLoopData = $availableSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-2">
                                <h2>
                                    <?php echo e($slot['day']); ?>

                                </h2>
                            </div>
                            <div class="col-10">
                                <div class="row">
                                    <?php $__currentLoopData = $slot['timeslots']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $timeslot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <form id="form<?php echo e($key+1 . $k+1); ?>" action="<?php echo e(route('patient.appointment.schedule.confirm', [$doctor->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <input hidden type="text" name="day" value="<?php echo e($slot['day']); ?>">
                                            <input hidden type="text" name="timeslot" value="<?php echo e($timeslot['time']); ?>">
                                            <span id="formReason<?php echo e($key+1 . $k+1); ?>"></span>
                                            <button onclick="submitForm(<?php echo e($key+1 . $k+1); ?>)" class="m-1 text-white btn btn-lg <?php if($timeslot['status'] == 1): ?> btn-info <?php else: ?> btn-danger <?php endif; ?>" <?php if($timeslot['status'] == 0): ?> disabled <?php endif; ?>><?php echo e($timeslot['time']); ?></button>
                                        </form>
                                        <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<script>
    function submitForm(id) {
        event.preventDefault();
        let form = $('#form'+id);
        let reason = $('#reason').val();
        if(!reason) {
            alert('Reason is required!');
            return;
        }
        $('#formReason'+id).html('<input hidden type="text" name="reason" value="'+ reason +'">');
        form = $('#form'+id);
        form.submit();
    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/patient/appointment/schedule.blade.php ENDPATH**/ ?>