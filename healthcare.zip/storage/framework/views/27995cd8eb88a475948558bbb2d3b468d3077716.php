

<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Appointments</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">Appointments</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <section id="doctor-index">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Appointments</h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        </div>
                        <?php if(session()->has('message')): ?>
                            <?php echo '
                                <div class=" col-6 offset-3 alert alert-success alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <strong>Success! </strong>'.session()->get('message').'
                                </div>
                            '; ?>

                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <?php echo implode('', $errors->all('
                                <div class=" col-6 offset-3 alert alert-danger alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <strong>Error!</strong> :message
                                </div>
                            ')); ?>

                        <?php endif; ?>
                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Patient Username</th>
                                            <th>Day</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Status</th>
                                            <th>Paid</th>
                                            <th style="width: 10%">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($appointment->id); ?></td>
                                                <td><?php echo e($appointment->patient->user->username); ?></td>
                                                <td><?php echo e($appointment->dayName()); ?></td>
                                                <td><?php echo e($appointment->start12()); ?></td>
                                                <td><?php echo e($appointment->end12()); ?></td>
                                                <td>
                                                    <?php if($appointment->status == 'BOOKED'): ?>
                                                        <div class="badge badge-danger">PENDING</div>
                                                    <?php elseif($appointment->status === 'DONE'): ?>
                                                        <div class="badge badge-success">DONE</div>
                                                    <?php elseif($appointment->status === 'CANCELED'): ?>
                                                        <div class="badge badge-info">CANCELED</div>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(($appointment->paid == 1) ? 'Paid' : 'Unpaid'); ?></td>
                                                <td class="btn-toolbar">
                                                    <div class="btn-group p-0">
                                                        <a class="btn btn-sm btn-outline-primary mr-1" href="#"
                                                           data-toggle="modal"
                                                           data-target='#appointment<?php echo e($appointment->id); ?>'>
                                                            <i class="la la-eye"></i>
                                                        </a>
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        <?php if($appointment->status == 'BOOKED'): ?>
                                                            <button class="btn btn-sm btn-outline-success mr-1" onclick="doneModal(<?php echo e($appointment->id); ?>)">
                                                                <i class="la la-check"></i>
                                                            </button>
                                                            <button class="btn btn-sm btn-outline-danger" onclick="cancelModal(<?php echo e($appointment->id); ?>)">
                                                                <i class="la la-close"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div class="modal fade" id="appointment<?php echo e($appointment->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h3 class="modal-title">View Appointment</h3>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Patient Username:</b> <?php echo e($appointment->patient->user->username); ?>

                                                                        </div>
                                                                        <div class="col">
                                                                            <b>Day:</b> <?php echo e($appointment->dayName()); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Start Time:</b> <?php echo e($appointment->start12()); ?>

                                                                        </div>
                                                                        <div class="col">
                                                                            <b>End Time:</b> <?php echo e($appointment->end12()); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <b>Reason for Appointment:</b> <?php echo e($appointment->reason); ?>

                                                                        </div>
                                                                    </div>
                                                                    <?php if($appointment->doctor_comment): ?>
                                                                        <div class="row mb-1">
                                                                            <div class="col">
                                                                                <b>Doctor Remarks:</b> <?php echo e($appointment->doctor_comment); ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="row mb-1">
                                                                        <div class="col">
                                                                            <?php if($appointment->paid): ?>
                                                                                <div class="badge badge-success">PAID</div>
                                                                            <?php else: ?>
                                                                                <div class="badge badge-danger">UNPAID</div>
                                                                            <?php endif; ?>
                                                                            <?php if($appointment->status == 'BOOKED'): ?>
                                                                                <div class="badge badge-danger">PENDING</div>
                                                                            <?php elseif($appointment->status == 'DONE'): ?>
                                                                                <div class="badge badge-success"><?php echo e($appointment->status); ?></div>
                                                                            <?php elseif($appointment->status == 'CANCELED'): ?>
                                                                                <div class="badge badge-info"><?php echo e($appointment->status); ?></div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                    <?php if($appointment->canceled_by): ?>
                                                                        <div class="row">
                                                                            <div class="col">
                                                                                <?php if($appointment->canceled_by == 'doctor'): ?>
                                                                                    <div class="badge badge-danger">Canceled by Doctor</div>
                                                                                <?php elseif($appointment->canceled_by == 'patient'): ?>
                                                                                    <div class="badge badge-danger">Canceled by Patient</div>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!----modal starts here--->
    <div id="cancelModal" class="modal fade" role='dialog'>
        <div class="modal-dialog">
            <form method="POST" action="<?php echo e(route('doctor.appointment.cancel')); ?>">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Cancel Appointment</h4>
                    </div>
                    <div class="modal-body">
                        <label for="reason">Reason for Cancellation ?</label>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <span id="cancelAppointment"></span>
                            <input id="reason" type="text" class="form-control" name="reason" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-info" data-dismiss="modal">Back</button>
                        <button type="submit" class="btn btn-danger">Cancel Appointment</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--Modal ends here--->
    <!----modal starts here--->
    <div id="doneModal" class="modal fade" role='dialog'>
        <div class="modal-dialog">
            <form method="POST" action="<?php echo e(route('doctor.appointment.done')); ?>">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Mark Appointment as Complete</h4>
                    </div>
                    <div class="modal-body">
                        <label for="doctor_comment">Remarks:</label>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <span id="doneAppointment"></span>
                            <input id="doctor_comment" type="text" class="form-control" name="doctor_comment">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-info" data-dismiss="modal">Back</button>
                        <button type="submit" class="btn btn-success">Mark Appointment as Complete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--Modal ends here--->
<?php $__env->stopSection(); ?>
<script>
    function cancelModal(id) {
        $('#cancelModal').modal();
        $('#cancelAppointment').html('<input hidden type="text" class="form-control" name="appointment" value="'+ id +'">');
    }
    function doneModal(id) {
        $('#doneModal').modal();
        $('#doneAppointment').html('<input hidden type="text" class="form-control" name="appointment" value="'+ id +'">');
    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/doctor/appointment/index.blade.php ENDPATH**/ ?>