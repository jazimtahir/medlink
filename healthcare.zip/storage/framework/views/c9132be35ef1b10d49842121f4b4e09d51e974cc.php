

<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Reviews</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="">Reviews</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <section>
            <div class="">
                <h3 class="">
                    My Reviews
                </h3>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $myReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card profile-card-with-cover">
                                <div class="card-content">
                                    <div class="profile-card-with-cover-content text-center mt-3">
                                        <h4 class="">
                                            <span>@</span><?php echo e($review->to_user->username); ?>

                                        </h4>
                                        <div class="card-body">
                                            <div>
                                                <?php
                                                    for($i = 1; $i<=5; $i++){
                                                        if($review->rating >= $i){
                                                            echo '<span><i class="la la-star text-warning"></i></span>';
                                                        }
                                                        else{
                                                            echo '<span><i class="la la-star-o"></i></span>';
                                                        }
                                                    }
                                                ?>
                                            </div>
                                            <div>
                                                <?php echo e($review->feedback); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h5 class="col text-danger">No reviews given</h5>
                    <?php endif; ?>
                </div>
            </div>
            <hr>
            <div class="">
                <h3 class="">
                    Reviews To Me
                </h3>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $reviewsToMe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card profile-card-with-cover">
                                <div class="card-content">
                                    <div class="profile-card-with-cover-content text-center mt-3">
                                        <h4 class="">
                                            <span>@</span><?php echo e($review->from_user->username); ?>

                                        </h4>
                                        <div class="card-body">
                                            <div>
                                                <?php
                                                    for($i = 1; $i<=5; $i++){
                                                        if($review->rating >= $i){
                                                            echo '<span><i class="la la-star text-warning"></i></span>';
                                                        }
                                                        else{
                                                            echo '<span><i class="la la-star-o"></i></span>';
                                                        }
                                                    }
                                                ?>
                                            </div>
                                            <div>
                                                <?php echo e($review->feedback); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h5 class="col text-danger">No reviews to me</h5>
                    <?php endif; ?>
                </div>
            </div>
            <hr>
            <div class="">
                <h3 class="">
                    Sumbit Review
                </h3>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $reviewable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card profile-card-with-cover">
                                <div class="card-content">
                                    <div class="profile-card-with-cover-content text-center mt-3">
                                        <h4 class="">
                                            <span>@</span><?php echo e($user->username); ?>

                                        </h4>
                                        <div class="card-body">
                                            <form action="<?php echo e(route('reviews.create')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('POST'); ?>
                                                <div class="">
                                                    <div class="input-group p-1">
                                                        <div class="d-inline-block custom-control custom-radio mr-1">
                                                            <input type="radio" name="rating" class="custom-control-input" id="r1<?php echo e($user->id); ?>" value="1">
                                                            <label class="custom-control-label" for="r1<?php echo e($user->id); ?>">Worst</label>
                                                        </div>
                                                        <div class="d-inline-block custom-control custom-radio mr-1">
                                                            <input type="radio" name="rating" class="custom-control-input" id="r2<?php echo e($user->id); ?>" value="2">
                                                            <label class="custom-control-label" for="r2<?php echo e($user->id); ?>">Bad</label>
                                                        </div>
                                                        <div class="d-inline-block custom-control custom-radio mr-1">
                                                            <input type="radio" name="rating" class="custom-control-input" id="r3<?php echo e($user->id); ?>" value="3">
                                                            <label class="custom-control-label" for="r3<?php echo e($user->id); ?>">Ok</label>
                                                        </div>
                                                        <div class="d-inline-block custom-control custom-radio mr-1">
                                                            <input type="radio" name="rating" class="custom-control-input" id="r4<?php echo e($user->id); ?>" value="4">
                                                            <label class="custom-control-label" for="r4<?php echo e($user->id); ?>">Good</label>
                                                        </div>
                                                        <div class="d-inline-block custom-control custom-radio">
                                                            <input type="radio" name="rating" class="custom-control-input" id="r5<?php echo e($user->id); ?>" value="5">
                                                            <label class="custom-control-label" for="r5<?php echo e($user->id); ?>">Excellent</label>
                                                        </div>
                                                    </div>
                                                    <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger">
                                                        <?php echo e($message); ?>

                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="d-flex align-items-baseline">
                                                    <label class="label">Feedback: </label>
                                                    <input name="user" type="text" class="form-control" hidden value="<?php echo e($user->id); ?>" required>
                                                    <input name="feedback" type="text" class="form-control" required>
                                                    <?php $__errorArgs = ['feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger">
                                                        <?php echo e($message); ?>

                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="pull-right p-1">
                                                    <button type="submit" class="btn btn-outline-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h5 class="col text-danger">No reviews to me</h5>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/review/index.blade.php ENDPATH**/ ?>