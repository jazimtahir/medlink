<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Appointments</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">Schedule New Appointment</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <section id="social-cards">

            <div class="row mt-2">
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if(!$doctor->doctor->schedule()->exists()) {
                        continue;
                    }
                    ?>
                    <div class="col-xl-4 col-md-6 col-12">
                        <div class="card profile-card-with-cover">
                            <div class="card-content">
                                <div class="row">
                                    <div class="col-6 offset-3 p-5">
                                        <img src="<?php echo e($doctor->getImg()); ?>" class="col rounded-circle img-border" alt="Card image">
                                    </div>
                                </div>
                                <div class="profile-card-with-cover-content text-center">
                                    <div class="profile-details">
                                        <h4 class="card-title">
                                            <?php if($doctor->is_verified): ?>
                                                <div class="badge badge-success">Verified</div>
                                            <?php else: ?>
                                                <div class="badge badge-danger">Unverified</div>
                                            <?php endif; ?>
                                        </h4>
                                        <h4 class="card-title"><span>@</span><?php echo e($doctor->username); ?>

                                            <?php switch($doctor->gender):
                                                case ('M'): ?>
                                                    <small>(Male)</small>
                                                    <?php break; ?>
                                                <?php case ('F'): ?>
                                                    <small>(Female)</small>
                                                    <?php break; ?>
                                                <?php case ('T'): ?>
                                                    <small>(Other)</small>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <small>(No Gender provided)</small>
                                            <?php endswitch; ?>
                                        </h4>
                                        <h4 class="card-title"><?php echo e((($doctor->doctor->salutation != null) ? ($doctor->doctor->salutation . '. ') : '') . $doctor->first_name . ' ' . $doctor->last_name); ?></h4>
                                        <?php if($doctor->doctor->specialization): ?>
                                            <h5 class="card-title text-muted">Specialized in <?php echo e($doctor->doctor->specialization->name); ?></h5>
                                        <?php endif; ?>
                                        <h4 class="card-title">Fee: <i>PKR </i><?php echo e($doctor->doctor->fee ?? 'N/A'); ?></h4>
                                        <h6 class="card-subtitle text-muted mt-1">
                                            <?php
                                                $doctor->rating = (int) $doctor->reviews_to_me()->avg('rating');
                                                for($i = 1; $i<=5; $i++){
                                                    if($doctor->rating >= $i){
                                                        echo '<span><i class="la la-star text-warning"></i></span';
                                                    }
                                                    else{
                                                        echo '<span><i class="la la-star-o"></i></span';
                                                    }
                                                }
                                            ?>
                                        </h6>
                                        <ul class="list-inline clearfix mt-2">
                                            <li class="mr-3">
                                                <h2 class="block"><?php echo e($doctor->doctor->activeAppointments()->count()); ?></h2> Active
                                            </li>
                                            <li class="mr-3">
                                                <h2 class="block"><?php echo e($doctor->doctor->canceledAppointments()->count()); ?></h2> Canceled
                                            </li>
                                            <li>
                                                <h2 class="block"><?php echo e($doctor->doctor->doneAppointments()->count()); ?></h2> Successful
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card-body">
                                        <a href="<?php echo e(route('patient.appointment.schedule', [$doctor->doctor->id])); ?>" class="btn btn-info btn-min-width mr-1 mb-1"><i class="la la-briefcase"></i>
                                            Get Appointment</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/patient/appointment/doctors.blade.php ENDPATH**/ ?>