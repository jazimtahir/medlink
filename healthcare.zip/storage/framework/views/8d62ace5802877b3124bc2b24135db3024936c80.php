<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <h3 class="content-header-title">Profile</h3>
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="">Profile</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <section>
            <div class="col-12">
                <div class="card m-0">
                    <div class="row">
                        <div class="col">
                            <div class="pull-right m-1">
                                <button class="btn btn-outline-warning" data-toggle="modal" data-target="#profileEdit"><i class="la la-edit"></i>Edit</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="text-center">
                                <div class="card-body">
                                    <img src="<?php echo e($user->getImg()); ?>" class="rounded-circle height-150" alt="Card image">
                                </div>
                                <div class="card-body">
                                    <h4 class="card-title"><?php echo e($user->first_name . ' ' . $user->last_name); ?></h4>
                                    <h6 class="card-subtitle text-muted"><span>@</span><?php echo e($user->username); ?></h6>
                                    <h6 class="card-subtitle text-muted mt-1">
                                        <?php
                                        for($i = 1; $i<=5; $i++){
                                            if($user->rating >= $i){
                                                echo '<span><i class="la la-star text-warning"></i></span';
                                            }
                                            else{
                                                echo '<span><i class="la la-star-o"></i></span';
                                            }
                                        }
                                        ?>
                                    </h6>
                                    <h6 class="card-subtitle text-muted mt-1">
                                        <?php switch($user->gender):
                                            case ('M'): ?>
                                                Male
                                                <?php break; ?>
                                            <?php case ('F'): ?>
                                                Female
                                                <?php break; ?>
                                            <?php case ('T'): ?>
                                                Other
                                                <?php break; ?>
                                            <?php default: ?>
                                                No Gender provided
                                        <?php endswitch; ?>
                                    </h6>
                                    <?php if($user->is_verified): ?>
                                        <span class="badge badge-success mt-1">Verified</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger mt-1">Unverified</span>
                                    <?php endif; ?>
                                    <?php if($user->is_active): ?>
                                        <span class="badge badge-success mt-1">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger mt-1">Unactive</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <?php if($errors->any()): ?>
                            <?php echo implode('', $errors->all('
                                <div class=" col-6 offset-3 alert alert-danger alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <strong>Error!</strong> :message
                                </div>
                            ')); ?>

                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-12 col-lg-6">
                            <div class="card-body">
                                <table class="table table-column">
                                    <tr>
                                        <td class="h5">Username:</td>
                                        <td><?php echo e($user->username); ?></td>
                                    </tr>
                                    <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
                                    <tr>
                                        <td class="h5">Salutation:</td>
                                        <td><?php echo e($user->doctor->salutation); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td class="h5">First Name:</td>
                                        <td><?php echo e($user->first_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Last Name:</td>
                                        <td><?php echo e($user->last_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Email:</td>
                                        <td><?php echo e($user->email); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Phone No:</td>
                                        <td><?php echo e($user->phone); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Date of Birth:</td>
                                        <td><?php echo e(date('d-m-Y', strtotime($user->dob))); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Address:</td>
                                        <td><?php echo e($user->address); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Bio:</td>
                                        <td><?php echo e($user->bio); ?></td>
                                    </tr>
                                    <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
                                    <tr>
                                        <td class="h5">Professional Statement:</td>
                                        <td><?php echo e($user->doctor->professional_statement); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Specialization:</td>
                                        <?php if($user->doctor->specialization): ?><td><?php echo e($user->doctor->specialization->name); ?><?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Fee:</td>
                                        <td><?php echo e($user->doctor->fee); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="h5">Practicing From:</td>
                                        <td><?php echo e(date('d-M-Y', strtotime($user->doctor->practicing_from))); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td class="h5">Created at:</td>
                                        <td><?php echo e(date('d-m-Y', strtotime($user->created_at))); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-lg-6">
                            <ul class="list-group list m-1">
                                <h3>Reviews</h3>
                                <?php $__currentLoopData = $user->reviews_to_me; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <div class="row">
                                            <div class="col-1">
                                                <img src="<?php echo e($review->from_user->getImg()); ?>" class="avatar">
                                            </div>
                                            <div class="col-11">
                                                <h3 class="name"><?php echo e($review->from_user->first_name. ' '. $review->from_user->last_name); ?></h3>
                                                <p class="born"><?php echo e($review->feedback); ?></p>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade text-left" id="profileEdit" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Edit Profile</h3>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-body">
                                <label>Username: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="text" name="username" value="<?php echo e($user->username); ?>" class="form-control" disabled>
                                    <div class="form-control-position">
                                        <i class="ft ft-user-check"></i>
                                    </div>
                                </div>

                                <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
                                <label>Salutation: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="text" name="username" value="<?php echo e($user->doctor->salutation); ?>" class="form-control">
                                    <div class="form-control-position">
                                        <i class="ft ft-activity"></i>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <label>Email: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" disabled>
                                    <div class="form-control-position">
                                        <i class="la la-envelope"></i>
                                    </div>
                                </div>

                                <label>Phone: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control" disabled>
                                    <div class="form-control-position">
                                        <i class="la la-phone"></i>
                                    </div>
                                </div>

                                <label>First Name: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="text" name="first_name" value="<?php echo e($user->first_name); ?>" class="form-control">
                                    <div class="form-control-position">
                                        <i class="la la-user"></i>
                                    </div>
                                </div>

                                <label>Last Name: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="text" name="last_name" value="<?php echo e($user->last_name); ?>" class="form-control">
                                    <div class="form-control-position">
                                        <i class="la la-user-plus"></i>
                                    </div>
                                </div>

                                <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
                                <label>Specialization: </label>
                                <div class="form-group position-relative">
                                    <select class=" custom-select form-control" name="specialization_id">
                                        <option></option>
                                        <?php $__currentLoopData = $specialization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($user->doctor->specialization && $user->doctor->specialization->name == $s->name): ?> selected <?php endif; ?> class="" value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <label>Practicing From: </label>
                                <div class="form-group position-relative">
                                    <input type="text" name="practicing_from" value="<?php echo e($user->doctor->practicing_from); ?>" class="date-picker form-control">
                                </div>

                                <label>Fee: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="number" name="fee" value="<?php echo e($user->fee); ?>" class="form-control">
                                    <div class="form-control-position">
                                        <i class="la la-money"></i>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <label>Password: </label>
                                <div class="form-group position-relative has-icon-left">
                                    <input type="password" name="password" placeholder="Password" class="form-control">
                                    <div class="form-control-position">
                                        <i class="la la-lock"></i>
                                    </div>
                                </div>

                                <label>Bio: </label>
                                <div class="form-group position-relative">
                                    <textarea class="form-control" rows="5" name="bio" placeholder="Enter text ..."><?php echo e($user->bio); ?></textarea>
                                </div>

                                <?php if(auth()->check() && auth()->user()->hasRole('doctor')): ?>
                                <label>Professional Statement: </label>
                                <div class="form-group position-relative">
                                    <textarea class="form-control" rows="5" name="professional_statement" placeholder="Enter text ..."><?php echo e($user->doctor->professional_statement); ?></textarea>
                                </div>
                                <?php endif; ?>

                                <label>Address: </label>
                                <div class="form-group position-relative">
                                    <textarea class="form-control" id="address" name="address" placeholder="Enter Address ..." rows="3"><?php echo e($user->address); ?></textarea>
                                </div>

                                <label>Date of Birth: </label>
                                <div class="form-group position-relative">
                                    <input type="text" class="date-picker form-control" name="dob" value="<?php echo e($user->dob); ?>">
                                </div>

                                <label>Profile Picture: </label>
                                <div class="form-group position-relative">
                                    <input type="file" class="form-control" name="image">
                                </div>

                            </div>
                            <div class="modal-footer">
                                <input type="reset" class="btn btn-outline-secondary" data-dismiss="modal" value="Close">
                                <input type="submit" class="btn btn-outline-primary" value="Save">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthcare\resources\views/profile/index.blade.php ENDPATH**/ ?>