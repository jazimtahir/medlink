<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light navbar-shadow">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
        <span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2022 <a class="text-bold-800 grey darken-2" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a></span>
        <span class="float-md-right d-none d-lg-block">Final Year Project by Jazim Tahir & Danish Jamil<span id="scroll-top"></span></span></p>
</footer>
<!-- END: Footer-->
<?php /**PATH C:\xampp\htdocs\healthcare\resources\views/layouts/footer.blade.php ENDPATH**/ ?>