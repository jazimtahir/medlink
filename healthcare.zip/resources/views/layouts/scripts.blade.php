<!-- BEGIN: Vendor JS-->
<script src="{{ asset('assets/vendors/js/vendors.min.js') }}"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="{{ asset('assets/vendors/js/ui/jquery.sticky.js') }}"></script>
<script src="{{ asset('assets/vendors/js/charts/jquery.sparkline.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/charts/chartist.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/charts/chartist-plugin-tooltip.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/charts/raphael-min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/charts/morris.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/timeline/horizontal-timeline.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/datatable/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/buttons.flash.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/jszip.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/pdfmake.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/vfs_fonts.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/buttons.html5.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/tables/buttons.print.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/extensions/datedropper.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/extensions/timedropper.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/forms/toggle/bootstrap-switch.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/forms/toggle/switchery.min.js') }}"></script>
<script src="{{ asset('assets/vendors/js/forms/toggle/bootstrap-checkbox.min.js') }}"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="{{ asset('assets/js/core/app-menu.min.js') }}"></script>
<script src="{{ asset('assets/js/core/app.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/customizer.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/footer.min.js') }}"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="{{ asset('assets/js/scripts/ui/breadcrumbs-with-stats.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/pages/dashboard-ecommerce.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/ui/breadcrumbs-with-stats.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/tables/datatables/datatable-advanced.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/extensions/date-time-dropper.min.js') }}"></script>
<script src="{{ asset('assets/js/scripts/forms/switch.min.js') }}"></script>
<!-- END: Page JS-->

<!-- timepicker -->
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
